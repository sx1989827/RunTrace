//
//  RunTrace.h
//  RunTrace
//
//  Created by 孙昕 on 15/9/18.
//  Copyright (c) 2015年 孙昕. All rights reserved.
//

#import <UIKit/UIKit.h>
#define RunTraceOpen 1
@interface RunTrace : UIView

@end
